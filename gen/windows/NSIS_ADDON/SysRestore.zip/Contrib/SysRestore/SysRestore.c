/******************************************************************
* System Restore Plugin                                           *
* Written by Jason Ross aka JasonFriday13 on the forums           *
*                                                                 *
* 2005 - 2006 MouseHelmet Software                                *
*                                                                 *
* Included license is applicable to this source code file.        *
*******************************************************************/

#include <windows.h>
#include "../ExDll/ExDll.h"
#include <srrestoreptapi.h>

// Link with srclient.lib
#pragma comment (lib, "srclient.lib")

HANDLE hInstance;

RESTOREPOINTINFO RestPtInfo;
STATEMGRSTATUS SMgrStatus;

BOOL RestorePointStarted = FALSE;

// This function is common to all functions. To reduce size,
// having one copy instead of two saves space (I think).
int SetRestorePoint(void)
{
  char *szTemp = (char*)LocalAlloc(LPTR, sizeof(char)*64);
  SRSetRestorePoint(&RestPtInfo, &SMgrStatus);
  wsprintf(szTemp, "%u", SMgrStatus.nStatus);
  pushstring(szTemp);
//MessageBox(0, szTemp, szTemp, 0);
  LocalFree(szTemp);
  return SMgrStatus.nStatus;
}

// These functions must be internal to the dll,
// because they use a global variable. It does
// not work if these functions are exported.
BOOL Begin(BOOL uninstaller)
{
  ZeroMemory(&RestPtInfo, sizeof(RESTOREPOINTINFO));
  ZeroMemory(&SMgrStatus, sizeof(STATEMGRSTATUS));

  // Initialize the RESTOREPOINTINFO structure
  RestPtInfo.dwEventType = BEGIN_SYSTEM_CHANGE;

  // Notify the system that changes are about to be made.
  // An application is to be installed (or uninstalled).
  if (uninstaller)
    RestPtInfo.dwRestorePtType = APPLICATION_UNINSTALL;
  else
    RestPtInfo.dwRestorePtType = APPLICATION_INSTALL;

  // Set RestPtInfo.llSequenceNumber.
  RestPtInfo.llSequenceNumber = 0;

  // String to be displayed by System Restore for this restore point.
  popstring(RestPtInfo.szDescription);
	    
  // Notify the system that changes are to be made and that
  // the beginning of the restore point should be marked. 
  return SetRestorePoint() == 0;
}

BOOL Finish(void)
{
  // Re-initialize the RESTOREPOINTINFO structure to notify the 
  // system that the operation is finished.
  RestPtInfo.dwEventType = END_SYSTEM_CHANGE;

  // End the system change by returning the sequence number 
  // received from the first call to SRSetRestorePoint.
  RestPtInfo.llSequenceNumber = SMgrStatus.llSequenceNumber;

  // Notify the system that the operation is done and that this
  // is the end of the restore point.
  return SetRestorePoint() == 0;
}

BOOL Remove(void)
{
  // Re-initialize the RESTOREPOINTINFO structure to notify the 
  // system that the operation is finished.
  RestPtInfo.dwEventType = END_SYSTEM_CHANGE;

  // Set to remove.
  RestPtInfo.dwRestorePtType = CANCELLED_OPERATION;

  // End the system change by returning the sequence number 
  // received from the first call to SRSetRestorePoint.
  RestPtInfo.llSequenceNumber = SMgrStatus.llSequenceNumber;

  // Remove the restore point.
  return SetRestorePoint() == 0;
}

void __declspec(dllexport) StartRestorePoint(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
  // This is to prevent multiple calls to SRSetRestorePoint.
  if (!RestorePointStarted)
  {
    EXDLL_INIT();
    if (Begin(FALSE))
      RestorePointStarted = TRUE;
  }
  else
    pushstring("1");
}

void __declspec(dllexport) StartUnRestorePoint(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
  // This is to prevent multiple calls to SRSetRestorePoint.
  if (!RestorePointStarted)
  {
    EXDLL_INIT();
    if (Begin(TRUE))
      RestorePointStarted = TRUE;
  }
  else
    pushstring("1");
}

void __declspec(dllexport) FinishRestorePoint(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
  // This is to prevent multiple calls to SRSetRestorePoint.
  if (RestorePointStarted)
  {
    EXDLL_INIT();
    if (Finish())
      RestorePointStarted = FALSE;
  }
  else
    pushstring("2");
}

void __declspec(dllexport) RemoveRestorePoint(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
  // This is to prevent multiple calls to SRSetRestorePoint.
  if (RestPtInfo.llSequenceNumber != 0)
  {
    EXDLL_INIT();
    if (Remove())
      RestPtInfo.llSequenceNumber = 0;
  }
  else
    pushstring("3");
}

void __declspec(dllexport) Unload(HWND hwndParent, int string_size, char *variables, stack_t **stacktop)
{
}

BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
  hInstance = hInst;
  return 1;
}